import React, { useState, useEffect } from "react";
import type { Toilet } from "../../types/toilet";
import { toilet } from "../../services/toilet.api";
import "./PendingList.scss";

const PendingList: React.FC = () => {
  const [pending, setPending] = useState<Toilet[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPending = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await toilet.listPending();
      setPending(data);
    } catch (err: any) {
      console.error(err);
      setError(
        err?.response?.data?.message ||
          "Erreur lors du chargement des toilettes en attente"
      );
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id: number) => {
    try {
      await toilet.approve(id);
      setPending((prev) => prev.filter((t) => t.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  const handleReject = async (id: number) => {
    try {
      await toilet.reject(id);
      setPending((prev) => prev.filter((t) => t.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchPending();
  }, []);

  if (loading) return <p className="loading">Chargement...</p>;
  if (error) return <p className="error">{error}</p>;

  return (
    <div className="pending-list-page">
      <h2>Toilettes en attente d’approbation</h2>
      {pending.length === 0 ? (
        <p className="no-data">Aucune toilette en attente</p>
      ) : (
        <div className="table-container">
          <table className="pending-table">
            <thead>
              <tr>
                <th>Nom</th>
                <th>Description</th>
                <th>Coordonnées</th>
                <th>Libre</th>
                <th>Accessible</th>
                <th>Propreté</th>
                <th>Créé par</th>
                <th>Date de création</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {pending.map((t) => (
                <tr key={t.id}>
                  <td>{t.name || "—"}</td>
                  <td>{t.description || "—"}</td>
                  <td>
                    {t.lat && t.lng
                      ? `${Number(t.lat).toFixed(5)}, ${Number(t.lng).toFixed(5)}`
                      : "—"}
                  </td>
                  <td>{t.isFree ? "✅" : "❌"}</td>
                  <td>{t.isAccessible ? "♿" : "—"}</td>
                  <td>{t.cleanliness || "N/A"}</td>
                  <td>{t.createdBy || "Inconnu"}</td>
                  <td>{t.createdAt ? new Date(t.createdAt).toLocaleString() : "—"}</td>
                  <td className="action-buttons">
                    <button
                      className="approve"
                      onClick={() => handleApprove(t.id!)}
                    >
                      ✅ Approuver
                    </button>
                    <button
                      className="reject"
                      onClick={() => handleReject(t.id!)}
                    >
                      ❌ Rejeter
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default PendingList;
